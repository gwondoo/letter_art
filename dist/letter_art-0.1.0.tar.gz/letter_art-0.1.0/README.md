# letter-art

이미지를 ASCII 문자 아트로 변환하는 Python 패키지
Python Package that makes image to ASCII code

---

## install

```bash
pip install letter-art
